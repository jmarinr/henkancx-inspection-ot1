import React from 'react'
export default function OCRConfirmModal(){ return null }
