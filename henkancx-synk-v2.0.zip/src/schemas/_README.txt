// Esquemas JSON simples para renderizado dinámico.
// Reemplaza los "name" y "label" por los nombres EXACTOS de tus plantillas si difieren.
