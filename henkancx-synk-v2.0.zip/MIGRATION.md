# MIGRATION

Para mapear exactamente los nombres de las plantillas a la UI, edita los archivos JSON en `src/schemas/`.
No requiere cambios de código; los componentes renderizan en base a estos esquemas.
