# CHANGELOG

## 2.0.0
- Login por código (cualquier código).
- Menú Wizard con secciones.
- Información básica (auto GPS + fecha ejecutada auto y no editable).
- Datos del vehículo.
- Formularios dinámicos (Ground, Infraestructura, Inventario, PMI) con esquemas JSON editables.
- Fotos por sección con títulos (sugerido 3+).
- PDF con misma estética base y secciones nuevas.
